require("dotenv").config();

const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));
app.set("view engine", "ejs");

// MySQL Connection
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

connection.connect((error) => {
  if (error) {
    console.log("Database connection failed");
    throw error;
  }
  console.log("Database connected successfully");
});


// Home Page – Registration Form
app.get("/", (req, res) => {
  res.render("register");
});


// Save Student Details
app.post("/add-student", (req, res) => {

  const studentData = {
    name: req.body.name,
    email: req.body.email,
    dob: req.body.dob,
    department: req.body.department,
    phone: req.body.phone
  };

  const insertQuery =
    "INSERT INTO students (name,email,dob,department,phone) VALUES (?,?,?,?,?)";

  connection.query(
    insertQuery,
    [
      studentData.name,
      studentData.email,
      studentData.dob,
      studentData.department,
      studentData.phone
    ],
    (err, result) => {
      if (err) {
        console.log(err);
      }
      res.redirect("/student-list");
    }
  );
});


// Display All Students
app.get("/student-list", (req, res) => {

  const selectQuery = "SELECT * FROM students";

  connection.query(selectQuery, (err, data) => {
    if (err) {
      console.log(err);
    }

    res.render("students", { students: data });
  });
});


// Server Start
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Application running at http://localhost:${PORT}`);
});